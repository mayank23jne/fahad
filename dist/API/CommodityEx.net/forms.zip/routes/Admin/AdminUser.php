<?php
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AdminPanel\AdminUserController;

Route::prefix('admin')->group(function(){
    Route::get('/users',[AdminUserController::class,'getUsers']);
});
