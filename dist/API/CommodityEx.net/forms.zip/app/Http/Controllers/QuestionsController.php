<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\StoreQuestionRequest;
use App\Models\Question;
use App\Models\Template;
use App\Models\Answer;
use App\Models\QuestionAnswer;
use App\Models\QuestionType;
use App\Http\Resources\QuestionResource;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class QuestionsController extends Controller
{
    function store(Request $req){
        // $validator = Validator::make($req->all(), [
        //     'FormName'=>'required',
        //     'Description'=>'required',
        // ]);
        // $req->validate([
        //     'FormName'=>'required',
        //     'Description'=>'required',
        // ]);
        $req->all();
        $form = new Template;
        $form->user_id = 1;
        $form->template_name  = $req['FormName'];
        $form->description  = $req['Description'];
        $form->save();

        foreach($req['Questions'] as $q){
            $question = new Question;
            $question->question = $q['Question'];
            $question->type_id  = $q['QuestionType'];
            $question->template_id  =$form->id;
            $question->save();
            $questionType = new QuestionType;
            $questionType = $questionType->find($q['QuestionType']);
            if ($questionType->multi_answer == 1){
                foreach ($q['Answers'] as $answer) {
                    $answerModel = new QuestionAnswer;
                    $answerModel->question_id = $question->id;
                    $answerModel->answer = $answer;
                    $answerModel->save();
                }
            }else{
                $answerModel = new QuestionAnswer;
                $answerModel->question_id = $question->id;
                $answerModel->answer = 'NULL';
                $answerModel->save();
            }
        }

        return response()->json([
                'message' => 'your forms successfully registered',
            ], 201);


    }

    // function show(){
    //     $questions = Question::with('template')->get();
    //     $questionTypes = Question::with('type')->get();
    //     $answers = question::with('answer')->get();

    //     // foreach ($questions as $question) {
    //     //     $data = [

    //     //             "FormName"=> $question->template_name,
    //     //             "Description"=>$question->description,
    //                 // "Questions"=>[
    //                 //        "Question"=> $question->question,
    //                 //         "QuestionType"=> $questionTypes->each(function ($questionType){
    //                 //             $questionType->type;
    //                 //         }),
    //                 //         "Answers"=> $answers->each(function ($answer){
    //                 //             $answer->answer;
    //                 //         }),

    //                 // ]
    //             // ];
    //             // }
    //             $templates = Template::all();
    //             foreach ($templates as $template) {
    //                     $data = [
    //                         "FormId"=>$template->id,
    //                         "FormName"=>$template->template_name,
    //                         "Description"=>$template->description,
    //                     ];
    //                     echo json_encode($data);
    //             }
    // }

    function show(){
        // return "hello";
        $templates = Question::with('template')->get();
        $answers = question::with('answer')->get();
                foreach ($templates as $form) {
                        $data = [
                            "id"=>$form->template->id,
                            "title"=>$form->template->template_name,
                            "detail"=>$form->template->description,
                            "category"=>$form->template->category,
                            "date"=>$form->template->created_at,
                            "Questions"=>[
                                "id"=> $form->id,
                                "question"=> $form->question,
                                "answerType"=>$form->type->id,
                                 "answers"=>$answers->each(function ($answer){
                                    $answer->answer;
                                 })
                                 ,
                            ]
                        ];
                        echo json_encode($data);
                }
    }

    function showForm($id){
        $template = Template::find($id);
        $forms = Question::where('template_id',$template->id)->get();
        foreach($forms as $form){
            $questionTypes = QuestionType::where('id',$form->type_id)->get();
            $answers = QuestionAnswer::where('question_id',$form->id)->get();
                $data = [

                        "FormName"=> $template->template_name,
                        "Description"=>$template->description,
                        "Questions"=>[
                               "Question"=> $form->question,
                                "QuestionType"=> $questionTypes->each(function ($questionType){
                                    $questionType->type;
                                }),
                                "Answers"=> $answers->each(function ($answer){
                                    $answer->answer;
                                }),

                        ]
                    ];
                    echo json_encode($data);
        };
    }
    // function showQuestion($id){
    //     $questions = Question::find($id)->template()->get();
    //     $questionTypes = Question::find($id)->type()->get();
    //     $answers = question::find($id)->answer()->get();
    //     foreach ($questions as $question) {
    //         $data = [

    //                 "FormName"=> $question->template_name,
    //                 "Description"=>$question->description,
    //                 "Questions"=>[
    //                        "Question"=> $question->question,
    //                         "QuestionType"=> $questionTypes->each(function ($questionType){
    //                             $questionType->type;
    //                         }),
    //                         "Answers"=> $answers->each(function ($answer){
    //                             $answer->answer;
    //                         }),

    //                 ]
    //             ];
    //         return json_encode($data);
    //     }
    // }
}
